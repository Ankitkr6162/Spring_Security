package io.spring.security.login.iospringsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IoSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
